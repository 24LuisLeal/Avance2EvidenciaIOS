//
//  Home.swift
//  Cinquo Photography
//
//  Created by Luis Leal on 25/11/21.
//

import SwiftUI

struct Home: View {
    
    @State var showMenu = false
    
    var body: some View {
        
        let drag = DragGesture()
            .onEnded{
                if($0.translation.width < -100){
                    withAnimation{
                        self.showMenu = false
                    }
                }
            }
        return NavigationView{
            GeometryReader{ geometry in
                ZStack(alignment: .leading){
                    CurrentScreenIndex(showMenu: self.$showMenu)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .offset(x: self.showMenu ? geometry.size.width/2 : 0)
                        .disabled(self.showMenu ? true : false)
                    
                    if(self.showMenu){
                        MenuItems()
                            .frame(width: geometry.size.width/2)
                            .transition(.move(edge: .leading))
                    }
                }
                .gesture(drag)
            }
            //Menú bar
            .navigationBarTitle(Text("Inicio"),displayMode: .inline)
            .navigationBarItems(leading: (
                Button(action: {
                    withAnimation{
                        self.showMenu.toggle()
                    }
                }){
                    Image(systemName: "line.horizontal.3")
                }
            ))
        }
    }
}


struct Card {
    var id : Int
    let titleCard : String
    let image : String
    let videoID : String
}


//Contenido en vista
struct CurrentScreenIndex : View{
    
    @Binding var showMenu : Bool
    
    var body: some View{
        ScrollView(.vertical){
            VStack{
                Text("Consejos")
                    .font(.title3)
                    .fontWeight(.light)
            }.frame(width: 350, height: 40, alignment: .topLeading)
                .padding(.top,5)
            //Contenido
            VStack{
                NavigationLink(destination: SomeViewRandom()){
                    CardView()
                }
                CardView()
            }
        }
    }
}

//Vista de una tarjeta
struct CardView : View{
    
    var body: some View{
        VStack{
            Image("1")
                .resizable()
                .frame(width:350,height: 250)
                .cornerRadius(20)
            Text("Consejo")
                .foregroundColor(.black)
                .font(.headline)
                .fontWeight(.light)
                .frame(width: 350, height: 30, alignment: .leading)
        }.padding(4)
    }
}


struct SomeViewRandom : View{
    var body: some View{
        Text("Aqui va un vídeo")
    }
}


struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            Home()
                .previewInterfaceOrientation(.portraitUpsideDown)
            Home()
                .previewInterfaceOrientation(.landscapeRight)
        }
    }
}
